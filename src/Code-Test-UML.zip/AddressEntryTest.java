import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * To test the Address Entry class.
 * 
 * @version 1.0
 *
 */
public class AddressEntryTest {

	// Entries to test with.
	private AddressEntry entry = new AddressEntry("Andy","Grewel","123 3rd Street", "Machan", "CA", 44214, "445-442-1234", "andy@mail.com");
	private AddressEntry entry2 = new AddressEntry("John","Micheal","224 Road", "Texas", "TX", 525234, "112-234-1235", "john@mail.com");
	
	/**
	 * Test 1
	 */
	@Test
	public void testConstructor() {
	
		new AddressEntry();
		assertEquals("Andy", entry.getFirstName());
		assertEquals("Grewel", entry.getLastName());
		assertEquals("123 3rd Street", entry.getStreet());
		assertEquals("Machan", entry.getCity());
		assertEquals("CA", entry.getState());
		assertEquals(44214, entry.getZip());
		assertEquals("445-442-1234", entry.getPhone());
		assertEquals("andy@mail.com", entry.getEmail());
		
	}

	/**
	 * Test 2
	 */
	@Test
	public void testFirstNameGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getFirstName());
		entry.setFirstName("Andy");
		assertEquals("Andy", entry.getFirstName());
		entry.setFirstName("John");
		assertEquals("John", entry.getFirstName());
		
	}

	/**
	 * Test 3
	 */
	@Test
	public void testLastNameGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getLastName());
		entry.setLastName("AndyP");
		assertEquals("AndyP", entry.getLastName());
		entry.setLastName("Johnson");
		assertEquals("Johnson", entry.getLastName());
		
	}

	/**
	 * Test 4
	 */
	@Test
	public void testStreetGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getStreet());
		entry.setStreet("123 3rd Street");
		assertEquals("123 3rd Street", entry.getStreet());
		entry.setStreet("123 4th Street");
		assertEquals("123 4th Street", entry.getStreet());
		
	}

	/**
	 * Test 5
	 */
	@Test
	public void testCityGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getCity());
		entry.setCity("Machan");
		assertEquals("Machan", entry.getCity());
		entry.setCity("Canny");
		assertEquals("Canny", entry.getCity());
		
	}

	/**
	 * Test 6
	 */
	@Test
	public void testStateGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getState());
		entry.setState("CA");
		assertEquals("CA", entry.getState());
		entry.setState("TX");
		assertEquals("TX", entry.getState());
		
	}

	/**
	 * Test 7
	 */
	@Test
	public void testZipGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals(0, entry.getZip());
		entry.setZip(11234);
		assertEquals(11234, entry.getZip());
		entry.setZip(6546);
		assertEquals(6546, entry.getZip());
		
	}

	/**
	 * Test 8
	 */
	@Test
	public void testPhoneGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getPhone());
		entry.setPhone("445-442-1234");
		assertEquals("445-442-1234", entry.getPhone());
		entry.setPhone("445-334-1234");
		assertEquals("445-334-1234", entry.getPhone());
		
	}

	/**
	 * Test 9
	 */
	@Test
	public void testEmailGetterSetter() {
	
		AddressEntry entry = new AddressEntry();
		assertEquals("", entry.getEmail());
		entry.setEmail("andy@mail.com");
		assertEquals("andy@mail.com", entry.getEmail());
		entry.setEmail("john@csu.com");
		assertEquals("john@csu.com", entry.getEmail());
		
	}

	/**
	 * Test 10
	 */
	@Test
	public void testToString() {
	
		assertEquals(entry.toString(), "Andy Grewel\n"
				+ "  123 3rd Street\n"
				+ "  Machan, CA 44214\n"
				+ "  andy@mail.com\n"
				+ "  445-442-1234");
		assertEquals(entry2.toString(), "John Micheal\n"
				+ "  224 Road\n"
				+ "  Texas, TX 525234\n"
				+ "  john@mail.com\n"
				+ "  112-234-1235");
		
	}
	
	
}
