import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * To test the Address Book class.
 * 
 * @version 1.0
 *
 */
public class AddressBookTest {

	// Entries to test with.
	private AddressEntry entry = new AddressEntry("Andy","Grewel","123 3rd Street", "Machan", "CA", 44214, "445-442-1234", "andy@mail.com");
	private AddressEntry entry2 = new AddressEntry("John","Micheal","224 Road", "Texas", "TX", 525234, "112-234-1235", "john@mail.com");
	private AddressBook book = new AddressBook();
	
	/**
	 * Test 1
	 */
	@Test
	public void testAdd() {
	
		assertEquals(0, book.list().size());
		book.add(entry);
		book.add(entry2);
		assertEquals(2, book.list().size());
		List<AddressEntry> entries = book.list();
		assertEquals(entry.toString(), entries.get(0).toString());
		assertEquals(entry2.toString(), entries.get(1).toString());
		
	}
	
	/**
	 * Test 1
	 */
	@Test
	public void testRemove() {
	
		book.add(entry);
		book.add(entry2);
		assertEquals(2, book.list().size());
		book.remove(entry);
		assertEquals(1, book.list().size());
		assertEquals(entry2.toString(), book.list().get(0).toString());
		book.add(entry);
		assertEquals(2, book.list().size());
		book.remove(entry2);
		assertEquals(1, book.list().size());
		assertEquals(entry.toString(), book.list().get(0).toString());
		
		
	}
	
	/**
	 * Test 1
	 */
	@Test
	public void testFind() {
	
		book.add(entry);
		book.add(entry2);
		AddressEntry entry3 = new AddressEntry("John","Grewel","223 3rd Street", "Machan", "CA", 54214, "345-442-1234", "johnandy@mail.com");
		book.add(entry3);
		List<AddressEntry> entries = book.find("miche");
		assertEquals(1, entries.size());
		assertEquals(entry2.toString(), entries.get(0).toString());
		entries = book.find("grewe");
		assertEquals(2, entries.size());
		assertEquals(entry.toString(), entries.get(0).toString());
		assertEquals(entry3.toString(), entries.get(1).toString());
		entries = book.find("");
		assertEquals(3, entries.size());
		
	}
	
	/**
	 * Test 1
	 */
	@Test
	public void testList() {
	
		book.add(entry);
		book.add(entry2);
		List<AddressEntry> entries = book.list();
		assertEquals(2, entries.size());
		assertEquals(entry.toString(), entries.get(0).toString());
		assertEquals(entry2.toString(), entries.get(1).toString());
		AddressEntry entry3 = new AddressEntry("John","Grewel","223 3rd Street", "Machan", "CA", 54214, "345-442-1234", "johnandy@mail.com");
		book.add(entry3);
		entries = book.list();
		assertEquals(3, entries.size());
		assertEquals(entry3.toString(), entries.get(2).toString());
		
	}
	
	/**
	 * Test 1
	 */
	@Test
	public void testReadWrite() {
	
		book.add(entry);
		book.add(entry2);
		try {
			book.save();
		} catch (IOException e) {
			fail(e.toString());
		}
		book = new AddressBook();
		try {
			book.readFromFile("Addresses.txt");
		} catch (FileNotFoundException e) {
			fail(e.toString());
		}
		List<AddressEntry> entries = book.list();
		assertEquals(2, entries.size());
		assertEquals(entry.toString(), entries.get(0).toString());
		assertEquals(entry2.toString(), entries.get(1).toString());
		AddressEntry entry3 = new AddressEntry("John","Grewel","223 3rd Street", "Machan", "CA", 54214, "345-442-1234", "johnandy@mail.com");
		book.add(entry3);
		try {
			book.save();
		} catch (IOException e) {
			fail(e.toString());
		}
		book = new AddressBook();
		try {
			book.readFromFile("Addresses.txt");
		} catch (FileNotFoundException e) {
			fail(e.toString());
		}
		entries = book.list();
		assertEquals(3, entries.size());
		assertEquals(entry3.toString(), entries.get(2).toString());
		
	}

}
